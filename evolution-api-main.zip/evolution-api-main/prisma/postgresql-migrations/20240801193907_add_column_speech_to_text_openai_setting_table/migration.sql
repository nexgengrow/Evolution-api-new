-- AlterTable
ALTER TABLE "OpenaiSetting" ADD COLUMN     "speechToText" BOOLEAN DEFAULT false;
